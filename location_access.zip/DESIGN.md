---
name: Neighborly Utility
colors:
  surface: '#f7fbf1'
  surface-dim: '#d8dbd2'
  surface-bright: '#f7fbf1'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f5ec'
  surface-container: '#ecefe6'
  surface-container-high: '#e6e9e0'
  surface-container-highest: '#e0e4db'
  on-surface: '#191d17'
  on-surface-variant: '#41493e'
  inverse-surface: '#2d322c'
  inverse-on-surface: '#eff2e9'
  outline: '#717a6d'
  outline-variant: '#c0c9bb'
  surface-tint: '#2a6b2c'
  primary: '#00450d'
  on-primary: '#ffffff'
  primary-container: '#1b5e20'
  on-primary-container: '#90d689'
  inverse-primary: '#91d78a'
  secondary: '#466270'
  on-secondary: '#ffffff'
  secondary-container: '#c6e4f4'
  on-secondary-container: '#4a6774'
  tertiary: '#6b1d3d'
  on-tertiary: '#ffffff'
  tertiary-container: '#883454'
  on-tertiary-container: '#ffaec6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#acf4a4'
  primary-fixed-dim: '#91d78a'
  on-primary-fixed: '#002203'
  on-primary-fixed-variant: '#0c5216'
  secondary-fixed: '#c9e7f7'
  secondary-fixed-dim: '#adcbda'
  on-secondary-fixed: '#001f2a'
  on-secondary-fixed-variant: '#2e4b57'
  tertiary-fixed: '#ffd9e2'
  tertiary-fixed-dim: '#ffb1c8'
  on-tertiary-fixed: '#3e001d'
  on-tertiary-fixed-variant: '#7a2949'
  background: '#f7fbf1'
  on-background: '#191d17'
  surface-variant: '#e0e4db'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 16px
  margin: 20px
---

## Brand & Style

This design system is built on the principles of **Neighborly Utility**. It balances the functional precision of a navigation app with the warmth of a local community center. The goal is to evoke a sense of "infrastructure-like ease"—where the UI feels like a reliable public service that is both essential and approachable.

The aesthetic leans into a **Modern / Corporate** style but softened with organic roundedness and a "map-calm" palette. It prioritizes legibility and spaciousness to reduce cognitive load, making the act of sharing items within a neighborhood feel safe, transparent, and effortless.

## Colors

The palette is anchored by a **Trustworthy Green** primary, reminiscent of Dutch park signage and sustainable infrastructure. This color is reserved for primary calls to action and confirmation states.

Secondary colors are intentionally muted—using dusty teals, soft ochres, and sage greens—to categorize community items without competing for the user's attention. In Light Mode, backgrounds utilize a warm "Paper White" to avoid screen glare. In Dark Mode, the system shifts to a deep "Charcoal Green" to maintain brand identity while ensuring high contrast for accessibility. Low-contrast borders (10-15% opacity) are used instead of heavy lines to define sections.

## Typography

This design system utilizes a dual-font strategy. **Plus Jakarta Sans** is used for headlines to provide a soft, modern, and welcoming character. Its open apertures and friendly curves make the app feel contemporary and "local."

**Inter** is employed for all body copy, inputs, and map labels. It offers exceptional clarity at small sizes and maintains a utilitarian, systematic feel that reinforces the app's reliability. Information hierarchy is established through weight shifts (Medium to Bold) rather than extreme size changes, ensuring a calm and steady reading experience.

## Layout & Spacing

The system follows an **8px grid** to ensure mathematical harmony across all components. The layout philosophy is a **Fluid Grid** with generous safe-area margins (20px on mobile). 

"Map-app calm" is achieved through comfortable whitespace; elements are never crowded. High-level sections use `lg` (40px) spacing to breathe, while related metadata uses `xs` or `sm` spacing. Grids for item listings should utilize 16px gutters to maintain clear separation while maximizing content density.

## Elevation & Depth

Depth is communicated primarily through **Tonal Layers** and extremely **Ambient Shadows**. Instead of dramatic shadows, this design system uses soft, wide-spread blurs with low opacity (4-8%) to lift cards slightly off the base canvas.

In Light Mode, elevation is supported by subtle 1px borders in a slightly darker shade than the surface. In Dark Mode, elevation is expressed through "Luminance Steps," where higher-elevation elements (like a modal or a floating action button) use a slightly lighter shade of the background gray rather than traditional shadows. This creates a tactile, stacked-paper effect that feels physical and trustworthy.

## Shapes

The shape language is defined by **Rounded Surfaces** (ROUND_TWELVE). A standard radius of 12px (0.75rem) is applied to all primary containers and cards, evoking a friendly and safe feel. 

Interactive elements like buttons and input fields use a slightly tighter 8px (0.5rem) radius to feel more "clickable" and precise. Floating Action Buttons (FABs) and certain map markers may use fully pill-shaped (rounded-full) geometry to stand out as distinct, touch-friendly objects within the interface.

## Components

### Buttons
Primary buttons use the Trustworthy Green with white text and an 8px corner radius. Secondary buttons should be "Ghost" style with a low-contrast border or a soft gray background, emphasizing the primary action.

### Cards
Cards are the primary vehicle for sharing items. They feature a 12px radius, a 1px soft border, and a subtle ambient shadow. Images within cards should have a top-only 12px radius to sit flush with the container.

### Chips & Tags
Use pill-shapes for category tags. Backgrounds should be the muted secondary colors (e.g., a soft Sage for "Gardening," a muted Blue for "Tools") with high-contrast text for accessibility.

### Inputs
Search bars and text fields should have a light gray fill and a subtle 1px border that shifts to the primary green on focus. Icons should be used within inputs to mimic the clarity of navigation apps.

### Map Pins
Custom map markers should be large and rounded, using the primary green for "available" items and a muted gray for "currently borrowed" items, ensuring instant legibility at a glance.